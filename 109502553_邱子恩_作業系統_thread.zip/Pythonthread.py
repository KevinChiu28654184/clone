import threading
import time  
from threading import Thread
import concurrent.futures
num = []
datas = input("請輸入數字，每個數字間請用空白區隔：").split(" ")
for data in datas:
    num.append(int(data))
def merge(left, right):
    result = []

    while len(left) and len(right):
        if (left[0] < right[0]):
            result.append(left.pop(0))
        else:
            result.append(right.pop(0))

    result = result + left if len(left) else result + right
    return result

def mergeSort(array):
    if len(array) < 2:
        return array

    mid = len(array) // 2
    leftArray = array[:mid]
    rightArray = array[mid:]    
    with concurrent.futures.ThreadPoolExecutor() as executor:
        thread1 = executor.submit(mergeSort, leftArray)
        thread2 = executor.submit(mergeSort, rightArray)
        return_value1 = thread1.result() 
        return_value2 = thread2.result()
    return merge(return_value1,return_value2)

print("排序後：",mergeSort(num))